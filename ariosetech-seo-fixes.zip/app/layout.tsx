import type { Metadata } from 'next'
// TEMP
import '@/styles/globals.css'

const manrope = { variable: '--font-manrope' }
const inter = { variable: '--font-inter' }

import localFont from 'next/font/local'
const roadRadio = localFont({
  src: '../public/fonts/RoadRadio-Bold.ttf',
  variable: '--font-logo',
  display: 'swap',
})

const LOGO = 'https://res.cloudinary.com/daeozrcaf/image/upload/v1776539376/ariosetech/wqycpdxj4iknsfi82fsd.png'
// Social share card. MUST be 1200x630 for WhatsApp/LinkedIn/Facebook/X to show
// a full-width preview instead of a small letterboxed logo. Upload a designed
// card (logo + tagline on the brand background) and put its URL here.
const OG_IMAGE = process.env.NEXT_PUBLIC_OG_IMAGE || LOGO
const FAVICON = 'https://res.cloudinary.com/daeozrcaf/image/upload/v1776539349/ariosetech/cmeul8vugjeeujikb4e5.png'

export const metadata: Metadata = {
  // Lets browsers, feed readers and aggregators auto-discover /rss.xml.
  alternates: { types: { 'application/rss+xml': [{ url: '/rss.xml', title: 'ARIOSETECH Blog' }] } },
  title: { default: 'ARIOSETECH, Consider It Solved', template: '%s | ARIOSETECH' },
  description: 'Professional WordPress, Shopify & WooCommerce development since 2017. 100+ businesses scaled globally.',
  metadataBase: new URL('https://ariosetech.com'),
  icons: {
    icon: FAVICON,
    shortcut: FAVICON,
    apple: FAVICON,
  },
  openGraph: {
    type: 'website', siteName: 'ARIOSETECH', locale: 'en_US',
    // Social platforms expect a 1200x630 landscape card. Declaring the real
    // dimensions stops WhatsApp/LinkedIn/FB from letterboxing it into a
    // white box. Replace OG_IMAGE with a proper 1200x630 designed card.
    images: [{ url: OG_IMAGE, width: 1200, height: 630, alt: 'ARIOSETECH — WordPress, Shopify & WooCommerce Development Agency' }],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'WordPress, Shopify & WooCommerce Development Agency',
    description: 'Professional WordPress, Shopify & WooCommerce development since 2017. 100+ businesses scaled.',
    images: [OG_IMAGE],
  },
}

import Animations from '@/components/ui/Animations'
import SpotlightEffect from '@/components/ui/SpotlightEffect'
import { getTheme, themeToCss } from '@/lib/theme'
import { getCollection } from '@/lib/db/mongodb'
import { organizationSchema, webSiteSchema } from '@/lib/schema'

// Rendered per request.
//
// This was briefly `revalidate = 3600`. That was wrong for this app: the root
// layout's force-dynamic had been forcing EVERY page to render per request, so
// switching it made the whole site prerender at build time — including pages
// whose files were never touched. Any page whose database read failed or came
// back empty during the build got that empty result baked in and served until
// the next revalidation.
//
// Caching is still worth doing here, but only once the build is known to reach
// MongoDB reliably. Correct beats fast.
export const dynamic = 'force-dynamic'

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const theme = await getTheme()

  // ── Site-wide Organization + WebSite schema ──
  // Read live from the settings collection so editing your address, phone,
  // email, or socials in the admin automatically updates the structured data.
  //
  // Why site-wide rather than homepage-only: every page-level schema on this
  // site (WebPage, Service, Article, CreativeWork) declares
  // `publisher: { "@id": ".../#organization" }`. Under schema.org's @id graph
  // model those references only resolve if the Organization node they point to
  // is present in the same document. Emitting it once per page is the standard
  // way to keep that graph valid — it is a single canonical node with a stable
  // @id, not duplicated conflicting entities, so Google de-duplicates it to one
  // organization. (Google's "one page per entity" advice targets duplicate
  // *conflicting* markup, not a shared @id node.)
  let orgLd: object | null = null
  let siteLd: object | null = null
  try {
    const col = await getCollection('settings')
    const doc = (await col.findOne({ key: 'site_settings' })) as Record<string, any> | null
    const s: Record<string, any> = (doc?.value ?? doc ?? {}) as Record<string, any>
    const addr = String(s.address || '95 College Road, Block E, PCSIR Staff Colony, Lahore, 54770')
    const parts = addr.split(',').map(x => x.trim())
    orgLd = organizationSchema({
      logo: s.logo_url || LOGO,
      description: 'WordPress, Shopify and WooCommerce development agency building e-commerce stores for businesses in the USA, UAE, UK and Switzerland since 2017.',
      foundingDate: '2017',
      email: s.email || 'info@ariosetech.com',
      telephone: s.phone || '+92 300 9484 739',
      address: {
        street: parts.slice(0, Math.max(1, parts.length - 2)).join(', ') || undefined,
        city: 'Lahore',
        region: 'Punjab',
        postalCode: parts[parts.length - 1] || undefined,
        country: 'PK',
      },
      sameAs: [s.facebook, s.instagram, s.linkedin, 'https://clutch.co/profile/ariosetech']
        .filter(Boolean) as string[],
      // ratingValue/reviewCount deliberately omitted. Self-serving
      // Organization ratings — where the reviewed entity controls the reviews
      // — are ineligible for rich results and are a Spammy Structured Markup
      // manual-action risk. The visible Clutch and Google review links are the
      // correct way to carry that trust signal.
    })
    siteLd = webSiteSchema()
  } catch {
    // Settings unavailable — still emit a baseline Organization so the graph
    // never breaks.
    orgLd = organizationSchema({ logo: LOGO, foundingDate: '2017' })
    siteLd = webSiteSchema()
  }

  return (
    <html lang="en" suppressHydrationWarning className={`${manrope.variable} ${inter.variable} ${roadRadio.variable}`}>
      <head>
        {/* Apply saved dark/light choice before first paint (no flash). Dark is default. */}
        <script dangerouslySetInnerHTML={{ __html:
          `try{var t=localStorage.getItem('theme');if(t==='light'){document.documentElement.dataset.theme='light'}}catch(e){}`
        }} />
        {/* Live brand theme from admin → overrides static defaults in globals.css */}
        <style id="site-theme" dangerouslySetInnerHTML={{ __html: themeToCss(theme) }} />
        {/* Site-wide structured data: Organization + WebSite. Present on every
            page so the publisher references in page-level schema resolve. */}
        {orgLd && (
          <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(orgLd) }} />
        )}
        {siteLd && (
          <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(siteLd) }} />
        )}
      </head>
      <body>
        <Animations />
        <SpotlightEffect />
        {children}
      </body>
    </html>
  )
}
