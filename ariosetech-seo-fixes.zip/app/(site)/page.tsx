import { getCollection } from '@/lib/db/mongodb'
import type { Metadata } from 'next'
import type { PageDoc, BlogDoc, PortfolioDoc } from '@/types'
import { BuilderRenderer } from '@/components/builder/canvas/BuilderRenderer'
import { webPageSchema, faqSchema, faqFromSections } from '@/lib/schema'
import HomeClient from './HomeClient'

// Rendered per request.
//
// This was briefly `revalidate = 3600`. That was wrong for this app: the root
// layout's force-dynamic had been forcing EVERY page to render per request, so
// switching it made the whole site prerender at build time — including pages
// whose files were never touched. Any page whose database read failed or came
// back empty during the build got that empty result baked in and served until
// the next revalidation.
//
// Caching is still worth doing here, but only once the build is known to reach
// MongoDB reliably. Correct beats fast.
export const dynamic = 'force-dynamic'

export async function generateMetadata(): Promise<Metadata> {
  try {
    const col = await getCollection<PageDoc>('pages')
    const page = await col.findOne({ fullPath: '/', status: 'published' })
    if (!page) return {}
    const seo = page.seo || {}
    const isIndexed = seo.robots?.index !== false
    const isFollowed = seo.robots?.follow !== false
    const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://ariosetech.com'
    const DEFAULT_OG_IMAGE = 'https://res.cloudinary.com/daeozrcaf/image/upload/v1776539376/ariosetech/wqycpdxj4iknsfi82fsd.png'
    const DEFAULT_DESC = 'Professional WordPress, Shopify & WooCommerce development since 2017. 100+ businesses scaled globally.'
    const DEFAULT_TITLE = 'WordPress, Shopify & WooCommerce Development Agency'
    // Never fall back to a bare page title like "Home" — it carries zero keywords
    // and is the single most valuable title on the domain. Only an explicit,
    // meaningful CMS SEO title should override the keyword-rich default.
    // Strip any brand suffix the admin typed — the root template appends it once.
    const cmsTitle = (seo.title || '').trim().replace(/\s*[|\u2014-]\s*ARIOSETECH\s*$/i, '')
    const title = cmsTitle && cmsTitle.toLowerCase() !== 'home' ? cmsTitle : DEFAULT_TITLE
    const description = seo.description || DEFAULT_DESC
    const ogImage = seo.ogImage || DEFAULT_OG_IMAGE
    return {
      title,
      description,
      keywords: seo.keywords?.length ? seo.keywords.join(', ') : undefined,
      openGraph: {
        type: 'website',
        siteName: 'ARIOSETECH',
        url: `${SITE_URL}/`,
        title: seo.ogTitle || title,
        description: seo.ogDescription || description,
        images: [ogImage],
      },
      twitter: {
        card: 'summary_large_image',
        title: seo.twitterTitle || title,
        description: seo.twitterDescription || description,
        images: [seo.twitterImage || ogImage],
      },
      alternates: {
        canonical: seo.canonicalUrl || `${SITE_URL}/`,
      },
      robots: `${isIndexed ? 'index' : 'noindex'},${isFollowed ? 'follow' : 'nofollow'}`,
    }
  } catch {
    return {}
  }
}

export default async function Home() {
  let layout = null

  try {
    const pagesCol = await getCollection<PageDoc>('pages')
    const page = await pagesCol.findOne({ fullPath: '/' })
    if (page?.layout?.sections && page.layout.sections.length > 0) {
      layout = page.layout
    }
  } catch (err) {
    console.error('Error fetching homepage layout:', err)
  }

  // If the dynamic builder layout is found, use it
  if (layout) {
    const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://ariosetech.com'

    // ── Homepage structured data ──
    // BuilderRenderer used to emit this indirectly, but it hardcoded
    // `type="Service"`, so the homepage claimed to be a commercial Service
    // offering literally named "Home". WebPage is what this page is; the
    // FAQPage comes from the FAQ section the page visibly renders. No
    // BreadcrumbList — the homepage has no breadcrumb trail to describe.
    const homeSchemas: object[] = [
      webPageSchema({
        title: 'WordPress, Shopify & WooCommerce Development Agency',
        description: 'Professional WordPress, Shopify & WooCommerce development since 2017. 100+ businesses scaled globally.',
        url: `${SITE_URL}/`,
      }),
    ]
    const homeFaqs = faqFromSections(layout.sections)
    if (homeFaqs.length > 0) homeSchemas.push(faqSchema(homeFaqs))

    return (
      <>
        {homeSchemas.map((s, i) => (
          <script key={i} type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(s) }} />
        ))}
        <BuilderRenderer sections={layout.sections} pageName="Home" pageUrl={`${SITE_URL}/`} />
      </>
    )
  }

  // Fallback to static HomeClient if DB fails or isn't seeded
  let blogs: Parameters<typeof HomeClient>[0]['blogs'] = []
  let portfolio: Parameters<typeof HomeClient>[0]['portfolio'] = []

  try {
    const [blogsCol, portfolioCol] = await Promise.all([
      getCollection<BlogDoc>('blogs'),
      getCollection<PortfolioDoc>('portfolio'),
    ])
    const [blogsRaw, portfolioRaw] = await Promise.all([
      blogsCol.find({ published: true }).sort({ date: -1 }).limit(3).toArray(),
      portfolioCol.find({ published: true }).sort({ featured: -1 }).limit(3).toArray(),
    ])

    blogs = blogsRaw.map(b => ({
      _id:      String(b._id),
      slug:     b.slug,
      title:    b.title,
      excerpt:  b.excerpt,
      category: b.category,
      date:     b.date,
      readTime: b.readTime ?? b.readingTime ?? 5,
    }))

    portfolio = portfolioRaw.map(p => ({
      _id:      String(p._id),
      slug:     p.slug,
      title:    p.title,
      client:   p.client,
      category: p.category,
      summary:  p.summary,
      results:  p.results,
      stack:    p.stack,
      featured: p.featured,
    }))
  } catch {
    // DB not configured — render with static fallback data in HomeClient
  }

  return <HomeClient blogs={blogs} portfolio={portfolio} />
}
