import { labelForSegment } from '@/lib/breadcrumb-labels'
/**
 * JSON-LD schema builders. Pure functions — given some facts about a page,
 * they return a schema.org object. Used both by the auto-attach on dynamic
 * pages and by the manual generator tool in the admin.
 */

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || 'https://ariosetech.com'
const ORG_NAME = 'ARIOSETECH'
const ORG_ID = `${SITE_URL}/#organization`

export type BreadcrumbItem = { name: string; url: string }

/** WebPage schema — the baseline for any content page. */
export function webPageSchema(opts: {
  title: string
  description?: string
  url: string
  image?: string
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebPage',
    name: opts.title,
    description: opts.description || undefined,
    url: opts.url,
    ...(opts.image ? { primaryImageOfPage: { '@type': 'ImageObject', url: opts.image } } : {}),
    isPartOf: { '@type': 'WebSite', name: ORG_NAME, url: SITE_URL },
    publisher: { '@id': ORG_ID },
  }
}

/** Service schema — for service/offering pages. */
export function serviceSchema(opts: {
  name: string
  description?: string
  url: string
  priceFrom?: string
  areaServed?: string[]
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Service',
    name: opts.name,
    description: opts.description || undefined,
    url: opts.url,
    provider: { '@type': 'Organization', name: ORG_NAME, '@id': ORG_ID, url: SITE_URL },
    ...(opts.areaServed?.length ? { areaServed: opts.areaServed } : { areaServed: ['PK', 'US', 'AE', 'CH', 'GB'] }),
    ...(opts.priceFrom
      ? { offers: { '@type': 'Offer', price: opts.priceFrom.replace(/[^0-9.]/g, ''), priceCurrency: 'USD', url: opts.url } }
      : {}),
  }
}

/** BreadcrumbList schema — helps search engines show the page hierarchy. */
export function breadcrumbSchema(items: BreadcrumbItem[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  }
}

/** FAQPage schema. */
export function faqSchema(faqs: { q: string; a: string }[]) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(f => ({
      '@type': 'Question',
      name: f.q,
      acceptedAnswer: { '@type': 'Answer', text: f.a },
    })),
  }
}

/**
 * Article / BlogPosting schema.
 *
 * `author` used to be emitted as an Organization no matter what was passed in.
 * Google's article guidance is explicit that the author should be the person
 * who wrote the piece, with a `url` pointing at a page about them — attributing
 * everything to the company is the weaker E-E-A-T signal and is what triggers
 * the "author missing url" warning in the Rich Results Test.
 *
 * Pass `authorUrl` (an /author/{slug} profile) to get a Person; without one it
 * still falls back to the Organization, because a Person with no URL and no
 * profile page behind it is a claim nothing on the site supports.
 */
export function articleSchema(opts: {
  headline: string
  description?: string
  url: string
  image?: string
  datePublished?: string
  dateModified?: string
  author?: string
  authorUrl?: string
  authorJobTitle?: string
  reviewedBy?: { name: string; url?: string; jobTitle?: string }
  keywords?: string[]
}) {
  const author = opts.author && opts.authorUrl
    ? {
        '@type': 'Person',
        name: opts.author,
        url: opts.authorUrl,
        ...(opts.authorJobTitle ? { jobTitle: opts.authorJobTitle } : {}),
        worksFor: { '@id': ORG_ID },
      }
    : { '@type': 'Organization', name: opts.author || ORG_NAME, '@id': ORG_ID }

  return {
    '@context': 'https://schema.org',
    '@type': 'BlogPosting',
    headline: opts.headline,
    description: opts.description || undefined,
    url: opts.url,
    image: opts.image ? [opts.image] : undefined,
    datePublished: opts.datePublished || undefined,
    dateModified: opts.dateModified || opts.datePublished || undefined,
    author,
    ...(opts.reviewedBy?.name
      ? {
          reviewedBy: {
            '@type': 'Person',
            name: opts.reviewedBy.name,
            ...(opts.reviewedBy.url ? { url: opts.reviewedBy.url } : {}),
            ...(opts.reviewedBy.jobTitle ? { jobTitle: opts.reviewedBy.jobTitle } : {}),
          },
        }
      : {}),
    ...(opts.keywords?.length ? { keywords: opts.keywords.join(', ') } : {}),
    inLanguage: 'en',
    publisher: { '@type': 'Organization', name: ORG_NAME, '@id': ORG_ID },
    mainEntityOfPage: { '@type': 'WebPage', '@id': opts.url },
  }
}

/** Build the breadcrumb trail from a URL path like /services/wordpress. */
export function trailFromPath(fullPath: string, _pageTitle?: string): BreadcrumbItem[] {
  // Labels come from the same helper the visible breadcrumb uses. Google
  // requires structured data to describe what is actually on the page, so the
  // two must not drift. The last crumb previously used the page title while
  // the visible trail used the URL segment — that mismatch is now gone.
  const trail: BreadcrumbItem[] = [{ name: 'Home', url: `${SITE_URL}/` }]
  const parts = fullPath.split('/').filter(Boolean)
  let acc = ''
  parts.forEach(part => {
    acc += `/${part}`
    trail.push({ name: labelForSegment(part), url: `${SITE_URL}${acc}` })
  })
  return trail
}

/** Detect whether a page path looks like a service page. */
export function isServicePath(fullPath: string): boolean {
  return /^\/services(\/|$)/.test(fullPath)
}

/* ═══════════════════════════════════════════════════════════════════════
   Organization + WebSite — the site-wide entity graph.
   Every other schema references ORG_ID as its publisher, so this MUST be
   emitted once site-wide (root layout) or those references resolve to
   nothing. This is the single most important schema for brand identity,
   knowledge-panel eligibility, and AI/LLM citation.
   ═══════════════════════════════════════════════════════════════════════ */
export function organizationSchema(opts?: {
  logo?: string
  sameAs?: string[]
  email?: string
  telephone?: string
  address?: { street?: string; city?: string; region?: string; postalCode?: string; country?: string }
  foundingDate?: string
  description?: string
  ratingValue?: string
  reviewCount?: string
}) {
  const o = opts || {}
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    '@id': ORG_ID,
    name: ORG_NAME,
    alternateName: 'ArioseTech',
    url: SITE_URL,
    ...(o.logo ? { logo: { '@type': 'ImageObject', url: o.logo } } : {}),
    ...(o.description ? { description: o.description } : {}),
    ...(o.foundingDate ? { foundingDate: o.foundingDate } : {}),
    ...(o.email || o.telephone ? {
      contactPoint: {
        '@type': 'ContactPoint',
        contactType: 'sales',
        ...(o.email ? { email: o.email } : {}),
        ...(o.telephone ? { telephone: o.telephone } : {}),
        availableLanguage: ['English', 'Urdu'],
      },
    } : {}),
    ...(o.address ? {
      address: {
        '@type': 'PostalAddress',
        ...(o.address.street ? { streetAddress: o.address.street } : {}),
        ...(o.address.city ? { addressLocality: o.address.city } : {}),
        ...(o.address.region ? { addressRegion: o.address.region } : {}),
        ...(o.address.postalCode ? { postalCode: o.address.postalCode } : {}),
        ...(o.address.country ? { addressCountry: o.address.country } : {}),
      },
    } : {}),
    ...(o.sameAs && o.sameAs.length ? { sameAs: o.sameAs } : {}),
    // WARNING: do not pass ratingValue/reviewCount for ARIOSETECH's own
    // Organization. Google does not show review snippets when the reviewed
    // entity controls the reviews, and markup that contradicts what the page
    // visibly displays is a Spammy Structured Markup manual-action risk.
    // Kept only for legitimate future use on Product/Service entities.
    ...(o.ratingValue && o.reviewCount ? {
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: o.ratingValue,
        reviewCount: o.reviewCount,
        bestRating: '5',
      },
    } : {}),
  }
}

/** WebSite schema with SearchAction — helps Google understand site search. */
export function webSiteSchema() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    '@id': `${SITE_URL}/#website`,
    name: ORG_NAME,
    url: SITE_URL,
    publisher: { '@id': ORG_ID },
  }
}

/** CreativeWork — for portfolio case-study pages. */
export function caseStudySchema(opts: {
  title: string
  description?: string
  url: string
  image?: string
  clientName?: string
  datePublished?: string
  keywords?: string[]
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'CreativeWork',
    name: opts.title,
    headline: opts.title,
    description: opts.description || undefined,
    url: opts.url,
    ...(opts.image ? { image: opts.image } : {}),
    ...(opts.datePublished ? { datePublished: opts.datePublished } : {}),
    ...(opts.clientName ? { about: { '@type': 'Organization', name: opts.clientName } } : {}),
    creator: { '@id': ORG_ID },
    publisher: { '@id': ORG_ID },
  }
}

/** ItemList — for hub pages listing children (industries, services, portfolio). */
export function itemListSchema(opts: {
  name: string
  url: string
  items: { name: string; url: string; description?: string }[]
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'ItemList',
    name: opts.name,
    url: opts.url,
    numberOfItems: opts.items.length,
    itemListElement: opts.items.map((it, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: it.name,
      url: it.url,
      ...(it.description ? { description: it.description } : {}),
    })),
  }
}

/**
 * Pull FAQ pairs out of a page's saved sections so FAQPage schema is generated
 * automatically whenever an editor adds/edits an FAQ section — no manual step.
 *
 * Hidden sections are skipped. BuilderRenderer renders only sections without
 * `meta.hidden`, so including them here would mark up questions and answers
 * that no visitor can see — the definition of unsupported structured data, and
 * the thing Google's spammy-markup policy actually penalises.
 */
export function faqFromSections(sections: unknown): { q: string; a: string }[] {
  if (!Array.isArray(sections)) return []
  const out: { q: string; a: string }[] = []
  for (const s of sections as Record<string, any>[]) {
    if (!s || s.type !== 'faq') continue
    if (s.meta?.hidden) continue
    const items = s.props?.items
    if (!Array.isArray(items)) continue
    for (const it of items) {
      const q = (it?.q ?? it?.question ?? '').toString().trim()
      const a = (it?.a ?? it?.answer ?? '').toString().trim()
      if (q && a) out.push({ q, a })
    }
  }
  return out
}

/** Person schema — for author profiles and bylines (EEAT signal). */
export function personSchema(opts: {
  name: string
  url: string
  jobTitle?: string
  description?: string
  image?: string
  sameAs?: string[]
  knowsAbout?: string[]
  email?: string
}) {
  return {
    '@context': 'https://schema.org',
    '@type': 'Person',
    '@id': `${opts.url}#person`,
    name: opts.name,
    url: opts.url,
    ...(opts.jobTitle ? { jobTitle: opts.jobTitle } : {}),
    ...(opts.description ? { description: opts.description } : {}),
    ...(opts.image ? { image: opts.image } : {}),
    ...(opts.email ? { email: opts.email } : {}),
    ...(opts.sameAs && opts.sameAs.length ? { sameAs: opts.sameAs } : {}),
    ...(opts.knowsAbout && opts.knowsAbout.length ? { knowsAbout: opts.knowsAbout } : {}),
    worksFor: { '@id': ORG_ID },
  }
}

/** ProfilePage schema — wraps an author page so Google reads it as a profile. */
export function profilePageSchema(opts: { name: string; url: string; person: object }) {
  return {
    '@context': 'https://schema.org',
    '@type': 'ProfilePage',
    name: opts.name,
    url: opts.url,
    mainEntity: opts.person,
  }
}
